'''
empleado: sueldo base
empleado por comision: ventas * comision
empleado por hora: valor * horas trabajas + he*valor*2
'''
class Empleado:
    def __init__(self, nombre, NIT):
        self.nombre = nombre
        self.NIT = NIT
    def calcular_sueldo(self):
        return 1000

class EmpleadoPorComision(Empleado):
    def __init__(self, nombre, NIT, ventas, comision):
        super().__init__(nombre, NIT)
        self.ventas = ventas
        self.comision = comision
    def calcular_sueldo(self):
        return self.ventas * self.comision

class EmpleadoPorHora(Empleado):
    def __init__(self, nombre, NIT, horas, he, valor):
        super().__init__(nombre, NIT)
        self.horas = horas
        self.he = he
        self.valor = valor
    def calcular_sueldo(self):
        return self.horas * self.valor + self.he*self.valor*2
