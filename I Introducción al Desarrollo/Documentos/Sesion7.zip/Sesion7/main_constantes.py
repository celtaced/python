from constantes import PI, Science

def main():
    print(f'PI: {PI}')

    print(f'Gravedad: {Science.GVD}')
    print(f'Gravedad: {Science.GRAVEDAD()}')

if __name__=='__main__':
    main()