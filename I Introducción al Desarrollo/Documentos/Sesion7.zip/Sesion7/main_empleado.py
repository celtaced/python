from empleado import Empleado, EmpleadoPorComision, EmpleadoPorHora

def main():
    alicia = Empleado('alicia', '37242379409213740')
    beto = EmpleadoPorComision('beto', '472384729', 3000, 0.3)
    eva = EmpleadoPorHora('eva', '4739573', 176, 10.00, 15)

    print(f'el sueldo de {alicia.nombre} es: ${alicia.calcular_sueldo():.2f}')
    print(f'el sueldo de {beto.nombre} es: ${beto.calcular_sueldo():.2f}')
    print(f'el sueldo de {eva.nombre} es: ${eva.calcular_sueldo():.2f}')

    if isinstance(alicia, Empleado):
        print('alicia es de tipo Empleado')

    if isinstance(beto, Empleado):
        print('beto es de tipo Empleado')

    if isinstance(eva, Empleado):
        print('eva es de tipo Empleado')

    if isinstance(eva, EmpleadoPorHora):
        print('eva es de tipo EmpleadoPorHora')

    if isinstance(eva, object):
        print('eva es de tipo object')

if __name__=='__main__':
    main()