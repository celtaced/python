class Factura:

    # variables de clase
    cantidad_facturas = 0

    def __init__(self, idfactura, cliente, total) -> None:
        self.idfactura = idfactura
        self.cliente = cliente
        self.total = total
        Factura.cantidad_facturas+=1

    @classmethod
    def mostrar_cantidad_facturas(cls):
        print(f'Se han generado {cls.cantidad_facturas} factura(s)')

    @staticmethod
    def sumar_facturas(lista_facturas):
        total = 0
        for factura in lista_facturas:
            total += factura.total

        return total