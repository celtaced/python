class Color:

    def __init__(self, color) -> None:
        self.color = color

    def mostrar_color(self):
        print(f'el color es: {self.color}')