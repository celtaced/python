from factura import Factura

def main():
    f1 = Factura(1, 'alicia', 1000)
    f2 = Factura(2, 'beto', 2000)
    f3 = Factura(3, 'eva', 3000)

    print(Factura.cantidad_facturas)
    print(f'f1: cant->{f1.cantidad_facturas} idfactura -> {f1.idfactura}')
    print(f'f2: cant->{f2.cantidad_facturas} idfactura -> {f2.idfactura}')
    print(f'f3: cant->{f3.cantidad_facturas} idfactura -> {f3.idfactura}')

    Factura.mostrar_cantidad_facturas()

    lista = [f1,f2,f3]
    print(f'la suma es: {Factura.sumar_facturas(lista)}')

if __name__=='__main__':
    main()