PI = 3.1416

class Science:
    GVD = 9.8

    @staticmethod
    def GRAVEDAD():
        return 9.8