MENU = '''
******************** Menu **********************
    Elija una opcion:
    [1] ISSS
    [2] AFP
    [3] ISR
    [4] Descuentos
    [5] Sueldo Gravable
    [6] Sueldo a pagar
    [#] Salir
************************************************
'''