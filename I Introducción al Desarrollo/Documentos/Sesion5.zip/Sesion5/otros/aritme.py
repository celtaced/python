def suma(a,b):
    return a+b

def resta(a,b):
    return a-b


print('MODULO: el valor de la varible global __name__ es', __name__)