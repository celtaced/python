# recursividad es una funcion que se llama a si misma
# siempre debe haber un caso base que detiene las llamadas recursivas
# recursividad es una alternativa a las estructuras repetitivas
# consumen muchos recursos de procesamiento

# 5! = 5x4x3x2x1 = 120

def factorial(n):
    if n==1:
        return 1
    return factorial(n-1)*n

print(f'el factorial es: {factorial(5)}')

# Ejercicio: Imprimir los valores descendentes de un numero, pedir n, si n=5, 5 4 3 2 1
