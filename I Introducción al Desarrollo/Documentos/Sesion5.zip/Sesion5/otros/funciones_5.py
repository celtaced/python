# programa para funciones de argumentos variables

# argumentos variables con lista
def listar_nombres(*nombres):
    for nombre in nombres:
        print(nombre)

listar_nombres('alicia', 'beto')
print('-----------------------------------------')
listar_nombres('alicia', 'beto', 'eva', 'camila', 'diana')

# argumentos variables con diccionario
def listar_terminos(**terminos):
    for k, v in terminos.items():
        print(f'llave: {k}, valor: {v}')

print('-----------------------------------------')
listar_terminos(PK='Primary Key', FK='Foreign Key', UQ='Unique')
print('-----------------------------------------')
listar_terminos(PK='Primary Key')