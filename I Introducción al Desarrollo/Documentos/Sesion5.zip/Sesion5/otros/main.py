import aritme

def main():
    print('SCRIPT: el valor de la varible global __name__ es', __name__)
    print(aritme.suma(10, 3))
    print(aritme.resta(10, 3))

if __name__=='__main__':
    main()