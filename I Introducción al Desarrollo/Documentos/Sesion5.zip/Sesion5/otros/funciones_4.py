# programa para valores por default
# valores opcionales, pueden o no ir
# isss = 3%
# afp = 7.25%

def calculo_isss_afp(sueldo: float, isss: float = 0.03, afp: float = 0.0725)-> tuple:
    '''
    la funcion calculo_isss_afp realiza el calculo del isss y afp a partir del sueldo\n
    el parametro isss es opcional y su valor por default es 3%\n
    el parametro afp es opcional y su valor por default es 7.25%\n
    los valores de retorno son el isss, el afp y la suma
    '''
    desc_afp = sueldo * afp
    if sueldo>=1000:
        desc_isss = 1000*isss
    else:
        desc_isss = sueldo*isss
    
    return desc_isss,desc_afp,desc_isss+desc_afp

descuento = calculo_isss_afp(1200)
print(descuento) # es una tupla
print(f'los descuentos son isss: $ {descuento[0]:.2f}, afp: $ {descuento[1]:.2f} y la suma: $ {descuento[2]:.2f}')

descuento2 = calculo_isss_afp(1200, 0.04)
descuento3 = calculo_isss_afp(1200, 0.04, 0.08)
descuento4 = calculo_isss_afp(1200, afp=0.08)
descuento5 = calculo_isss_afp(1200, afp=0.08, isss=0.04)
descuento6 = calculo_isss_afp(1200, isss=0.04)
