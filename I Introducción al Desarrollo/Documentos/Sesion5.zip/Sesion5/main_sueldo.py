from calculos import isr
from utilerias.menu import MENU

def main():
    print(MENU)
    op = int(input('digite una opcion: '))

    if op>=1 and op<=6:
        sueldo = float(input('digite el sueldo: '))
        if op==1:
            isss = isr.isss(sueldo)
            print(f'el descuento de isss es: $ {isss:.2f}')
        elif op==2:
            afp = isr.afp(sueldo)
            print(f'el descuento de afp es: $ {afp:.2f}')
        elif op==3:
            ISR = isr.isr(sueldo)
            print(f'el descuento de ISR es: $ {ISR:.2f}')
        # TODO implementar las 3 opciones faltantes
if __name__=='__main__':
    main()