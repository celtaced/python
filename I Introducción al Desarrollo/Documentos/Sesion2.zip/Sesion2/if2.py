# programa para determinar si una persona es adulta

edad = int(input('digite su edad: '))

if edad > 0 and edad<18:
    print('es menor de edad')
elif edad>=18 and edad<60:
    print('es mayor de edad')
elif edad >= 60 and edad <=115:
    print('es de la tercera edad')
else:
    print('la edad no es valida')

# if edad<5:
#     print('es un infante')