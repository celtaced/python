# programa para operadores de reasignacion

n = input("digite un numero: ")
print(type(n))
print('el numero digitado es: ' + n)

n = int(n)
n += 10 # n = n + 10
print(n)
n -= 5
print(n)
# /= //= *= ** %
m = 10
print(f'el resultado es: {n} y el valor de m es {m}')