# programa para operadores de comparacion

a = 10
b = 3

print(a==b)
print(a!=b)
print(a<b)
print(a>b)
print(a<=b)
print(a>=b)

print(type(a==b))
cad1 = 'hola'
cad2 = 'Hola'
print(cad1.lower()==cad2.lower())
