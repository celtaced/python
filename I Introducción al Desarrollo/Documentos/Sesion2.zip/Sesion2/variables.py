# programa para uso de variables

saludo = 'hola desde mi primer programa'
print(saludo)
print(type(saludo))  # el tipo de saludo es str

edad = 25
print(edad)
print(type(edad))  # el tipo de edad es int

precio = 105.73
print(precio)
print(type(precio))  # el tipo de precio es float

es_blanco = True  # False
print(es_blanco)
print(type(es_blanco))  # el tipo es es_blanco es bool
