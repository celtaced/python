
menu = '\n************** Menu ***************\n'
menu += '1. Bitcoin a Dolar \n'
menu += '2. Dolar a Bitcon \n'
menu += '3. Dolar a Colon \n'
menu += '**********************************\n'

print(menu)
op = int(input('Digite una opcion: '))

cantidad = float(input('Digite la cantidad a convertir: '))
conversion = 0.0
if op==1:
    conversion = cantidad*38500
elif op==2:
    conversion = cantidad/38500
elif op==3:
    conversion = cantidad*8.75

print(f'el resultado es: {conversion:.2f}')
