# programa para operadores aritmeticos y conversion de tipos

a = 10
b = 3

print('la suma es: ' + str(a + b))
print('la resta es:', a - b)
c = '10'
print(a*b+int(c))
print(a/b)
print(a//b)
print(a % b)
print(a**b)

# ()
# **
# / // % *
# + -
