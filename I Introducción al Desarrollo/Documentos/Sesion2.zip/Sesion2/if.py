# programa para determinar si una persona es adulta

edad = int(input('digite su edad: '))

if edad >=18:
    print('es mayor de edad')
    if edad>=60:
        print('y es de la tercera de edad')
    print('saliendo del programa ... ')
else:
    print('es menor de edad')
    print('programa termina')