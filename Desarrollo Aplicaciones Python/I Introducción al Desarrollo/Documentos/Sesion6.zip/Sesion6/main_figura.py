from rectangulo import Rectangulo
from figura import Figura

def main():
    r = Rectangulo('Rectangulo', 20, 10)
    f = Figura('Figura')
    f.mostrar_nombre()
    r.mostrar_nombre()
    print(f'el area del {r.nombre} es: {r.calcular_area()}')
    print(f'el perimetro del {r.nombre} es: {r.calcular_perimetro()}')
    
if __name__=='__main__':
    main()