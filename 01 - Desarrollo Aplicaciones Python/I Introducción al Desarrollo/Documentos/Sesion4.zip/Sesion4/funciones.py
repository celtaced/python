# programa para uso de funciones

def mi_primera_funcion():
    print('esta es mi primera funcion')

mi_primera_funcion()
mi_primera_funcion()
mi_primera_funcion()

# funcion -> retorna un valor
# procedimiento -> no retorna un valor

def suma(a, b):
    c = a + b
    return c

x = suma(10, 5)
print(x)
print(suma(12, 5))
