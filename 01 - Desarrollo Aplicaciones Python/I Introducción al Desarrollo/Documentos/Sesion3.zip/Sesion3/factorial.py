# programa para calcular el factorial de un numero
# 5! = 5x4x3x2x1 = 120

numero = int(input('digite un numero: '))


factorial = 1

# i = 1
# while i<=numero:
#     factorial*=i # factorial = factorial * i
#     i+=1 # i = i + 1

for i in range(1, numero+1): # range no genera el ultimo numero en el rango
    factorial*=i

print(f'el factorial de {numero} es: {factorial}')

# range sin valor inicial
for i in range (10):
    print(i)