nombres = ['alicia', 'beto', 'camila', 'diana']

# obtener el tama;o de la lista
print(len(nombres))
print(nombres)

# acceder a un elemento por su posicion
print(nombres[2])

# modificar un elemento
nombres[3] = 'eva'
print(nombres)

# agregar elementos
nombres.append('daniel')
print(nombres)

# eliminar elementos
nombres.remove('beto')
# nombres.pop(1) # por posicion
print(nombres)

# recorrer el array
for nombre in nombres:
    print(nombre)

# limpiar la lista
nombres.clear()
print(nombres)

del nombres[2]
print(nombres)