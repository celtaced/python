nombres = {'alicia', 'beto', 'camila', 'diana'}

print(len(nombres))
print(nombres)

# son de tama;o dinamico
nombres.add('eva')
print(nombres)

nombres.discard('camila')
print(nombres)

# no se puede modificar, es inmutable
# nombres[0] = 'fran'

for nombre in nombres:
    print('-', nombre)

nombres.clear()
print(nombres)

# frozenset es de tama;o estatico
lenguajes = frozenset({'c#','c++','php',1})
for leng in lenguajes:
    print('-', leng)

# elementos unicos en un set y conversion entre colecciones
lista = [1,2,7,9,4,1,5,1]
conjunto = set(lista)
print(conjunto)