lenguajes = ('C++', 'PHP', 'JAVA', 'Python', 'JavaScript')

print(len(lenguajes))
print(lenguajes[3])

# no se puede modificar elementos, es inmutable
# lenguajes[0] = 'C#'
for lenguaje in lenguajes:
    print('-',lenguaje)