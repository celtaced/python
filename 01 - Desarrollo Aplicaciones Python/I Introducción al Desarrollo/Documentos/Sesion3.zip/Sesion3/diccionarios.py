# diccionarios par llave: valor
# nombre: 'alicia'
diccionario = {
    'usuario': 'alicia',
    'correo': 'alicia@gmail.com',
    'token': 'akfhgwieurksdhfskdfhkdghdfkghdfgwiere',
}
print('Usuario:', diccionario['usuario'])
print('Correo:', diccionario['correo'])
print('Token:', diccionario['token'])
# modificar elementos
diccionario['usuario'] = 'eva'
print('Usuario modificado:', diccionario['usuario'])
# agregar elementos
diccionario['telefono'] = '12345678'
print('Telefono:', diccionario['telefono'])
# eliminar elementos
diccionario.pop('usuario')
# recorrer el diccionario
for valor in diccionario.values():
    print('-',valor)

for llave in diccionario.keys():
    print('*',llave)

for k, v in diccionario.items():
    print(f'{k}: {v}')
    
print('usuario' in diccionario)